﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UsersProject.API.Helper
{
    public class SwaggerRestrictions
    {
        public string AllowEndpoints { get; set; }
        public string ExcludeEnpoints { get; set; }
        public string AllowSchemas { get; set; }
        public string ExcludedSchemas { get; set; }

    }
}
