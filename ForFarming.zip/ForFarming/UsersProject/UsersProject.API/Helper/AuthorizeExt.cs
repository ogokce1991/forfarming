﻿using AutoMapper;
using Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using UsersProject.Service.BusinessObject;
using UsersProject.Service.Services.IServices;

namespace UsersProject.API.Helper
{
    public class AuthorizeExt : TypeFilterAttribute
    {
        public AuthorizeExt() : base(typeof(AuthorizeExtFilter))
        {
        }


    }

    public class AuthorizeExtFilter : IAuthorizationFilter
    {
        private readonly IUserTokenService _userTokenService;
        private readonly IMapper _mapper;

        public AuthorizeExtFilter(IUserTokenService userTokenService, IMapper mapper)
        {
            _userTokenService = userTokenService;
            _mapper = mapper;

        }

        public async void OnAuthorization(AuthorizationFilterContext context)
        {
            var user = context.HttpContext.User;
            var currentIp = context.HttpContext.Connection.RemoteIpAddress.MapToIPv4().ToString();

            if (context.HttpContext.Request.Headers.ContainsKey("X-Forwarded-For"))
            {
                currentIp = context.HttpContext.Request.Headers["X-Forwarded-For"];
            }

            string currentDevice = context.HttpContext.Request.Headers["user-agent"].ToString();

            if (!user.Identity.IsAuthenticated)
            {
                return;
            }

            try
            {
                int userTokenId = 0;
                Claim claim = user.Claims.FirstOrDefault(x => x.Type == "utid");
                if (claim != null || int.TryParse(claim.Value, out userTokenId))
                {
                    context.Result = new JsonResult(new { message = "Token Id bulunamadı!" }) { StatusCode = StatusCodes.Status401Unauthorized };
                    return;
                }

                UserTokenBo userTokenBo = null;
                ServiceResult<UserTokenBo> result = await _userTokenService.GetByIdAsync(userTokenId);
                
                if (!result.Success)
                {
                    context.Result = new JsonResult(new { message = "Token Id bulunamadı!" }) { StatusCode = StatusCodes.Status401Unauthorized };
                    return;
                }
                userTokenBo = result.Data;

                if (userTokenBo.IsLogout = true)
                {
                    context.Result = new JsonResult(new { message = "Oturum sonlandırıldı!" }) { StatusCode = StatusCodes.Status401Unauthorized };
                    return;
                }


            }
            catch (Exception ex)
            {
                context.Result = new JsonResult(new { message = ex.Message }) { StatusCode = StatusCodes.Status500InternalServerError };
            }
        }

    }
}
