﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UsersProject.API.Helper
{
    public class Enum
    {
    }

    public static class GrandFilterType
    {
        public const string Or = "Or";
        public const string And = "And";

    }

    public static class GrandPermission
    {
        public const string EndPointPermission = "EndPointPermission";
    }

    public static class Grands
    {
        public const string OrganizationCreate = "1";

        public const string UserCreate = "5";

        public const string RoleCreate = "9";

        public const string UserLoginCreate = "13";

        public const string CustomerRead = "135";
    }
}
