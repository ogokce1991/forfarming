﻿using Common;
using Common.Dto;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using UsersProject.API.Helper;
using UsersProject.Core.Model;
using UsersProject.Service.BusinessObject;
using UsersProject.Service.Services.IServices;

namespace UsersProject.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly JWTSettings jwtSettings;
        private readonly IUsersService _usersService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IUserTokenService _userTokenService;



        string useridStr = string.Empty;
        string tokenStr = string.Empty;
        Claim claim = null;
        int userTokenId = 0;

        public UsersController(
            IOptions<JWTSettings> jwtSettings,
            IHttpContextAccessor httpContextAccessor,
            IUsersService usersService,
            IUserTokenService userTokenService

            )
        {
            this.jwtSettings = jwtSettings.Value;
            _usersService = usersService;
            _userTokenService = userTokenService;
            _httpContextAccessor = httpContextAccessor;

            if (_httpContextAccessor != null && _httpContextAccessor.HttpContext != null && _httpContextAccessor.HttpContext.User != null)
            {
                useridStr = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
                if (string.IsNullOrEmpty(useridStr))
                    useridStr = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

                tokenStr = _httpContextAccessor.HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
                if (string.IsNullOrEmpty(tokenStr))
                    tokenStr = "";

                claim = httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "utid");
                if (claim != null)
                {
                    if (!int.TryParse(claim.Value, out userTokenId))
                    {
                        userTokenId = 0;
                    }
                }



            }


        }

        [HttpPost("GetToken")]
        [AllowAnonymous]
        public async Task<GenericResponse<TokenResponseDto>> GetToken([FromBody] TokenDto dto)
        {
            //userı çek kullanıcı adı ve şifre ile
            //user null kontrolü yap
            //gettokenresponseasync methodunu al
            if (String.IsNullOrEmpty(dto.UserName) || String.IsNullOrEmpty(dto.Password))
            {
                return GenericResponse<TokenResponseDto>.Error(ResultType.Error, "Parametreler boş olamaz!", "UC_GT_01", StatusCodes.Status500InternalServerError);
            }

            ServiceResult<IEnumerable<UserBo>> result;
            UserBo user = null;
            result = await _usersService.FindAsync(dto.UserName, dto.Password);

            if (result.Success)
            {
                user = result.Data.FirstOrDefault();

            }

            if (user == null)
            {
                return GenericResponse<TokenResponseDto>.Error(ResultType.Error, result.Error, "UC_GT_02", StatusCodes.Status404NotFound);
            }


            ServiceResult<TokenResponseDto> userTokenResult = null;

            try
            {
                var resultActiveToken = await _userTokenService.ExpiryOtherDeviceTokens(user.Id);

                if (resultActiveToken.Success != true)
                {
                    return GenericResponse<TokenResponseDto>.Error(ResultType.Error, "Kullanıcının eski oturumları kapatılamadı!", "UC_GT_03", StatusCodes.Status404NotFound);
                }
                userTokenResult = await GetTokenResponseAsync(user);

                if (!userTokenResult.Success)
                {
                    return GenericResponse<TokenResponseDto>.Error(ResultType.Error, userTokenResult.Error, "UC_GT_04", StatusCodes.Status500InternalServerError);
                }

                return GenericResponse<TokenResponseDto>.Ok(userTokenResult.Data);
            }
            catch (Exception)
            {

                throw;
            }




        }

        [HttpPost("GetVerifyToken")]
        [AllowAnonymous]
        public async Task<GenericResponse<TokenResponseVerifyDto>> GetVerifyToken([FromBody] TokenVerifyDto tokenVerifyDto)
        {
            if (tokenVerifyDto.Code == "" || tokenVerifyDto.Code == null)
            {
                return GenericResponse<TokenResponseVerifyDto>.Error(ResultType.Error, "Giriş yapılamadı!", "UC_GVT_01", StatusCodes.Status404NotFound);
            }
            if (tokenVerifyDto.UserTokenId == null || tokenVerifyDto.UserTokenId == 0)
            {
                return GenericResponse<TokenResponseVerifyDto>.Error(ResultType.Error, "Giriş yapılamadı!", "UC_GVT_02", StatusCodes.Status404NotFound);
            }
            UserTokenBo user = null;
            ServiceResult<UserTokenBo> resultToken;
            TokenResponseVerifyDto response = new TokenResponseVerifyDto();
            ServiceResult<UserBo> userResponse;
            ServiceResult<IEnumerable<UserBo>> userResult;
            string accessToken = "";
            UserBo users = null;
            resultToken = await _userTokenService.GetByVerifyIdAsync(tokenVerifyDto.UserTokenId);

            if (resultToken.Success)
            {
                userResult = await _usersService.FindAsync(resultToken.Data.UserEntity.UserName, resultToken.Data.UserEntity.Password);
                if (userResult.Success)
                {
                    users = userResult.Data.FirstOrDefault();

                    response.AccessToken = resultToken.Data.AccessToken;
                    response.RefreshToken = resultToken.Data.RefreshToken;
                    response.ExpiryDate = new DateTimeOffset(resultToken.Data.ExpiryDate).ToUnixTimeSeconds();
                    response.FirstName = users.FirstName;
                    response.LastName = users.LastName;
                    //response.UserTypeId = users.usert;
                    response.EmailAddress = users.EmailAddress;
                    //response.OrganizationId = users.o
                    response.Id = users.Id;
                    //response.GaIsActive = users.ga



                }
            }
            else
                return GenericResponse<TokenResponseVerifyDto>.Error(ResultType.Error, "Giriş yapılamadı!", "UC_GVT_03", StatusCodes.Status404NotFound);

            return GenericResponse<TokenResponseVerifyDto>.Ok(response);
        }

        [HttpGet]
        [GrandAuthorize(GrandPermission.EndPointPermission, Grands.CustomerRead)]
        public async Task<IEnumerable<UserDto>> GetList()
        {
            ServiceResult<IEnumerable<UserBo>> resultList = await _usersService.GetAsync();
            if (resultList.Success)
            {
                return (IEnumerable<UserDto>)resultList;
            }
            return null;

        }

        [HttpDelete("DeleteUser")]
        [GrandAuthorize(GrandPermission.EndPointPermission, Grands.CustomerRead)]
        public bool DeleteUser(UserEntity entity )
        {
            try
            {
                _usersService.DeleteUser(entity);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        [HttpPut("UpdateUser")]
        public bool UpdateUser(UserEntity entity)
        {
            try
            {
                _usersService.UpdateUser(entity);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /*[HttpPost]
        [HttpPut]
        [HttpDelete]
        [HttpGet]
        [HttpPost]*/


        private async Task<ServiceResult<TokenResponseDto>> GetTokenResponseAsync(UserBo user)
        {
            ServiceResult<TokenResponseDto> response = null;

            try
            {
                string accessToken = "";
                string refreshToken = GenerateRefreshToken();
                UserTokenBo userTokenBo = GenerateUserToken(user);
                userTokenBo.RefreshToken = refreshToken;
                userTokenBo.AccessToken = "";
                ServiceResult<UserTokenBo> userTokenResult = await _userTokenService.CreateAsync(userTokenBo);
                if (!userTokenResult.Success)
                {
                    response = new ServiceResult<TokenResponseDto>(null, false, "Bir hata meydana geldi!");
                    return response;
                }
                userTokenBo = userTokenResult.Data;
                try
                {
                    accessToken = await GenerateAccessToken(userTokenBo.Id, user);
                }
                catch (Exception ex)
                {
                    response = new ServiceResult<TokenResponseDto>(null, false, "Bir hata meydana geldi!");
                    return response;
                }

                userTokenBo.AccessToken = accessToken;
                await _userTokenService.UpdateAsync(userTokenBo.Id, userTokenBo);

                TokenResponseDto tokenResponseDto = UserBo.ConvertToTokenResponseDto(user);

                tokenResponseDto.UserTokenId = userTokenResult.Data.Id;
                response = new ServiceResult<TokenResponseDto>(tokenResponseDto, true, "");

                return response;


            }
            catch (Exception)
            {

                throw;
            }
        }

        private string GenerateRefreshToken()
        {
            string refreshToken = "";
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                refreshToken = Convert.ToBase64String(randomNumber);
            }
            return refreshToken;
        }
        private UserTokenBo GenerateUserToken(UserBo userBo)
        {
            UserTokenBo userToken = new UserTokenBo();
            userToken.UserId = userBo.Id;
            userToken.LoginTime = DateTime.Now;

            userToken.ExpiryDate = DateTime.Now.AddHours(1);
            string ip = HttpContext.Connection.RemoteIpAddress.MapToIPv4().ToString();
            if (Request.Headers.ContainsKey("X-Forwarded-For"))
            {
                ip = Request.Headers["X-Forwarded-For"];
            }
            userToken.CreatedIp = ip;
            return userToken;

        }

        private async Task<string> GenerateAccessToken(long userTokenId, UserBo userBo)
        {
            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim("utid", Convert.ToString(userTokenId)));
            claims.Add(new Claim(ClaimTypes.Name, Convert.ToString(userBo.Id)));
            string grandIds = "";

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(jwtSettings.SecretKey);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.Now.AddHours(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                EncryptingCredentials = new EncryptingCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.Aes128KW, SecurityAlgorithms.Aes128CbcHmacSha256)

            };
            SecurityToken token = null;
            try
            {
                token = tokenHandler.CreateToken(tokenDescriptor);
            }
            catch (Exception ex)
            {

                throw;
            }
            return tokenHandler.WriteToken(token);

        }
    }
}
