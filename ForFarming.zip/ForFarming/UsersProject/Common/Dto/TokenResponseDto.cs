﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Dto
{
    public class TokenResponseDto
    {
        public int Id { get; set; }
        public int UserTokenId { get; set; }
        public int RemainedAttempt { get; set; }
        public bool IsSms { get; set; }

    }
}
