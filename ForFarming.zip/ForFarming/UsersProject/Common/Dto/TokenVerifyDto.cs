﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Dto
{
    public class TokenVerifyDto
    {
        public int UserTokenId { get; set; }
        public string Code { get; set; }

    }
}
