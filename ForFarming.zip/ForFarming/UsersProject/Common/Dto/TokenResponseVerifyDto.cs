﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Dto
{
    public class TokenResponseVerifyDto
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public long OrganizationId { get; set; }
        public DateTime? LastLoginTime { get; set; }
        public long UserTypeId { get; set; }
        public string AccessToken { get; set; }
        public byte GaIsActive { get; set; }
        public string RefreshToken { get; set; }
        public int RemainedAttempt { get; set; }
        public long ExpiryDate { get; set; }

    }
}
