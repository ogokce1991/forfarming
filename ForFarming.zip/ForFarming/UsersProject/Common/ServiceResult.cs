﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class ServiceResult<T>
    {
        public readonly bool Success;
        public readonly T Data;
        public readonly string Error;

        public ServiceResult(T data, bool success, string error = "")
        {
            this.Data = data;
            this.Success = success;
            this.Error = error;            
        }
    }
    public class ServiceResult
    {
        public readonly bool Success;
        public readonly string Error;

        public ServiceResult(bool success, string error = "")
        {
            this.Success = success;
            this.Error = error;

        }
    }
}
