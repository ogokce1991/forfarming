﻿using Microsoft.EntityFrameworkCore;
using UsersProject.Core.Model;

namespace UsersProject.Data
{
    public partial class BaseDbContext: DbContext
    {
        public BaseDbContext()
        {

        }

        public BaseDbContext(DbContextOptions<BaseDbContext> options) : base(options)
        {
        }

        public virtual DbSet<UserEntity> UserEntities { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=DESKTOP-EUOV4QC; Database=ForFarming; Trusted_Connection=True; MultipleActiveResultSets=true;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserEntity>(entity =>
            {
                entity.ToTable("UserEntity");

                entity.Property(e => e.Id).HasColumnName("Id");




            });

            modelBuilder.Entity<UserTokenEntity>(entity =>
            {
                entity.ToTable("UserTokenEntityy");

                entity.Property(e => e.Id).HasColumnName("Id");

                entity.Property(e => e.AccessToken).HasColumnName("AccessToken");
                entity.Property(e => e.ExpiryDate).HasColumnName("ExpiryDate").HasColumnType("datetime");
                entity.Property(e => e.IsLogout).HasColumnName("IsLogout");
                entity.Property(e => e.LoginTime).HasColumnName("LoginTime").HasColumnType("datetime");
                entity.Property(e => e.LogoutTime).HasColumnName("LogoutTime").HasColumnType("datetime");
                entity.Property(e => e.RefreshToken).HasColumnName("RefreshToken");
                entity.Property(e => e.CreatedIp).HasColumnName("CreatedIp").HasMaxLength(255);
                entity.Property(e => e.IsOldToken).HasColumnName("IsOldToken");
                entity.Property(e => e.UserEntity).HasColumnName("UserEntity");


                entity.HasOne(d => d.UserId).WithMany(p => p.UserToken).HasForeignKey(d => d.UserEntity);


            });
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
