﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UsersProject.Core.IRepositories;
using UsersProject.Core.IUnitOfWork;
using UsersProject.Core.Model;
using UsersProject.Data.Repositories;

namespace UsersProject.Data.UnitOfWork
{
    public class UnitOfWork :IUnitOfWork
    {
        private readonly BaseDbContext _context;

        private UserRepository _userRepository;
        private UserTokenRepository _userTokenRepository;

        public UnitOfWork(BaseDbContext appDbContext)
        {
            _context = appDbContext;
        }


        public IUserRepository<UserEntity> UserRepositories => _userRepository = _userRepository ?? new UserRepository(_context);
        public IUserTokenRepository<UserTokenEntity> UserTokenRepository => _userTokenRepository = _userTokenRepository ?? new UserTokenRepository(_context);
        

        public async Task CommitAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}
