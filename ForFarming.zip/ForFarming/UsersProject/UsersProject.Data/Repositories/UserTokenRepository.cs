﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UsersProject.Core.IRepositories;
using UsersProject.Core.Model;

namespace UsersProject.Data.Repositories
{
    public class UserTokenRepository : IUserTokenRepository<UserTokenEntity>
    {
        private readonly BaseDbContext _context;
        private readonly DbSet<UserTokenEntity> _dbSet;

        public UserTokenRepository(BaseDbContext context)
        {
            _context = context;
            _dbSet = _context.Set<UserTokenEntity>();
        }

        public async Task<IEnumerable<UserTokenEntity>> GetUserActiveToken(int userid)
        {
            DateTime dt = DateTime.Now;
            return await _dbSet.Where(x => x.UserId == userid && x.ExpiryDate > dt && x.IsLogout == false).ToListAsync();
        }

        public async Task UpdateAsync(object id, UserTokenEntity entityToUpdate )
        {
            UserTokenEntity entity = await GetByIdAsync(id);
            CopyEntity(entityToUpdate, entity);
            _context.Entry(entity).State = EntityState.Modified;
        }

        public async Task InsertAsync(UserTokenEntity entity)
        {
            await _dbSet.AddAsync(entity);
        }

        public async Task<UserTokenEntity> GetByIdAsync(object id)
        {
            return await _dbSet.FindAsync(id);
        }

        public void CopyEntity(UserTokenEntity src, UserTokenEntity target)
        {
            var fromProperties = src.GetType().GetProperties();
            var toProperties = target.GetType().GetProperties();

            foreach (var fromProperty in fromProperties)
            {
                foreach (var toProperty in toProperties)
                {
                    if (fromProperty.Name == toProperty.Name && fromProperty.PropertyType == toProperty.PropertyType)
                    {
                        toProperty.SetValue(target, fromProperty.GetValue(src));
                        break;
                    }
                }
            }

        }
    }
}
