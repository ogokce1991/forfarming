﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UsersProject.Core.IRepositories;
using UsersProject.Core.Model;

namespace UsersProject.Data.Repositories
{
    public class UserRepository : IUserRepository<UserEntity>
    {
        private readonly BaseDbContext _context;
        private readonly DbSet<UserEntity> _dbSet;

        public UserRepository(BaseDbContext context)
        {
            _context = context;
            _dbSet = _context.Set<UserEntity>();
        }

        public async Task<IEnumerable<UserEntity>> GetListAsync()
        {
            IQueryable<UserEntity> query = _dbSet;
            return await query.ToListAsync();
        }

        public async Task InsertAsync(UserEntity entity)
        {
            await _dbSet.AddAsync(entity);
        }

        public async Task<IEnumerable<UserEntity>> FindAsync(string userName, string password)
        {
            //IQueryable<UserEntity> query = _dbSet;
            //query =
            return await _context.Set<UserEntity>().Where(x => x.UserName == userName && x.Password == password).ToListAsync();

        }

        public void Delete(UserEntity _object)
        {
            _context.Remove(_object);
            _context.SaveChanges();
        }
    }
}
