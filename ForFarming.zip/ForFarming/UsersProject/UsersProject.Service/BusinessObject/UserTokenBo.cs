﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsersProject.Service.BusinessObject
{
    public class UserTokenBo
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string AccessToken { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string RefreshToken { get; set; }
        public bool IsLogout { get; set; }
        public DateTime LoginTime { get; set; }
        public DateTime LogoutTime { get; set; }
        public string CreatedIp { get; set; }
        public bool IsOldToken { get; set; }
        public virtual UserBo UserEntity { get; set; }
    }
}
