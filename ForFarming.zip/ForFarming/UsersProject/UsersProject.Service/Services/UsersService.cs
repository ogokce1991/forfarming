﻿using AutoMapper;
using Common;
using Common.Dto;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using UsersProject.Core.IUnitOfWork;
using UsersProject.Core.Model;
using UsersProject.Service.BusinessObject;
using UsersProject.Service.Services.IServices;

namespace UsersProject.Service.Services
{
    public class UsersService : IUsersService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        private readonly IHttpContextAccessor _httpContextAccessor;

        string useridStr = "";
        string tokenStr = "";

        public UsersService(IUnitOfWork unitOfWork, IMapper mapper, ILookupNormalizer lookupNormalizer, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _httpContextAccessor = httpContextAccessor;

            if (_httpContextAccessor != null && _httpContextAccessor.HttpContext != null && _httpContextAccessor.HttpContext.User != null)
            {
                useridStr = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
                if (string.IsNullOrEmpty(useridStr))
                    useridStr = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

                tokenStr = _httpContextAccessor.HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
                if (string.IsNullOrEmpty(tokenStr))
                    tokenStr = "";
            }


        }

        public async Task<ServiceResult<IEnumerable<UserBo>>> GetAsync()
        {
            try
            {
                IEnumerable<UserBo> data = (await _unitOfWork.UserRepositories.GetListAsync()).Select(x=> _mapper.Map<UserBo>(x));
                return new ServiceResult<IEnumerable<UserBo>>(data, true);
            }
            catch (Exception ex)
            {
                return new ServiceResult<IEnumerable<UserBo>>(null, false, ex.Message);
            }
        }

        public async Task<ServiceResult<IEnumerable<UserBo>>> FindAsync(string userName, string password)
        {
            try
            {
                if (String.IsNullOrEmpty(userName) || String.IsNullOrEmpty(password))
                {
                    return new ServiceResult<IEnumerable<UserBo>>(null, false, "Parametreler boş olamaz!");
                }

                IEnumerable<UserEntity> entities = await _unitOfWork.UserRepositories.FindAsync(userName, password);

                if (entities != null && entities.Count() != 0)
                {
                    IEnumerable<UserBo> bos = entities.Select(t => _mapper.Map<UserBo>(t));
                    foreach (var item in bos)
                    {
                        item.Password = "";
                    }
                    return new ServiceResult<IEnumerable<UserBo>>(bos, true, null);
                }
                else
                    return new ServiceResult<IEnumerable<UserBo>>(null, false, "Kullanıcı bulunamadı!");

            }
            catch (Exception ex)
            {
                return new ServiceResult<IEnumerable<UserBo>>(null, false, "Bir hata oluştu!");
            }
        }

        public bool DeleteUser(UserEntity entity)
        {

            try
            {
                 _unitOfWork.UserRepositories.Delete(entity);
                     
                return true;
            }
            catch (Exception)
            {
                return true;
            }

        }
        //Update Person Details  entity
        public bool UpdateUser(UserEntity entity)
        {
            try
            {
                var DataList = _person.GetAll().Where(x => x.IsDeleted != true).ToList();
                foreach (var item in DataList)
                {
                    _person.Update(item);
                }
                return true;
            }
            catch (Exception)
            {
                return true;
            }
        }
    }
}
