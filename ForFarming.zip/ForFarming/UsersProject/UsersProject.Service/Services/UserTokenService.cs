﻿using AutoMapper;
using Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using UsersProject.Core.IUnitOfWork;
using UsersProject.Core.Model;
using UsersProject.Service.BusinessObject;
using UsersProject.Service.Services.IServices;

namespace UsersProject.Service.Services
{
    public class UserTokenService : IUserTokenService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        private readonly IHttpContextAccessor _httpContextAccessor;

        string useridStr = "";
        string tokenStr = "";

        public UserTokenService(IUnitOfWork unitOfWork, IMapper mapper, ILookupNormalizer lookupNormalizer, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _httpContextAccessor = httpContextAccessor;

            if (_httpContextAccessor != null && _httpContextAccessor.HttpContext != null && _httpContextAccessor.HttpContext.User != null)
            {
                useridStr = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);
                if (string.IsNullOrEmpty(useridStr))
                    useridStr = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

                tokenStr = _httpContextAccessor.HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
                if (string.IsNullOrEmpty(tokenStr))
                    tokenStr = "";
            }


        }



        public async Task<ServiceResult> ExpiryOtherDeviceTokens(int userId)
        {
            if (userId <= 0)
                return new ServiceResult(false, "Kullanıcı bilgisi yanlış!");

            try
            {
                var activeTokens = await _unitOfWork.UserTokenRepository.GetUserActiveToken(userId);
                foreach (var token in activeTokens)
                {
                    token.LogoutTime = DateTime.Now;
                    token.IsLogout = true;
                    token.IsOldToken = true;
                    await _unitOfWork.UserTokenRepository.UpdateAsync(token.Id, token);
                }
                await _unitOfWork.CommitAsync();
                return new ServiceResult(true);
            }
            catch (Exception ex)
            {
                return new ServiceResult(false, ex.Message);
            }
        }

        public async Task<ServiceResult<UserTokenBo>> CreateAsync(UserTokenBo bo)
        {
            if (bo == null)
                return new ServiceResult<UserTokenBo>(null, false, "USertoken info is empty!");

            try
            {
                UserTokenEntity entity;
                if (bo.Id > 0)
                {
                    entity = await _unitOfWork.UserTokenRepository.GetByIdAsync(bo.Id);
                    if (entity != null)
                        return new ServiceResult<UserTokenBo>(null, false, "userotken already exist!");
                    else
                        bo.Id = 0;


                }

                entity = _mapper.Map<UserTokenEntity>(bo);
                await _unitOfWork.UserTokenRepository.InsertAsync(entity);
                await _unitOfWork.CommitAsync();
                bo = _mapper.Map<UserTokenBo>(entity);

                return new ServiceResult<UserTokenBo>(bo, true);
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<ServiceResult> UpdateAsync(int id, UserTokenBo bo)
        {
            if (bo == null)
                return new ServiceResult(false, "usertokendto is empty");

            try
            {
                UserTokenEntity entity;

                if (bo.Id > 0 && id == bo.Id)
                {
                    entity = await _unitOfWork.UserTokenRepository.GetByIdAsync(id);
                    entity.ExpiryDate = bo.ExpiryDate;
                    entity.AccessToken = bo.AccessToken;
                    entity.RefreshToken = bo.RefreshToken;
                    entity.LoginTime = bo.LoginTime;
                    entity.LogoutTime = bo.LogoutTime;
                    entity.UserId = bo.UserId;
                    entity.IsLogout = bo.IsLogout;

                    await _unitOfWork.UserTokenRepository.UpdateAsync(id, entity);
                    await _unitOfWork.CommitAsync();

                    if (entity == null)
                        return new ServiceResult(false, "Usertoken not found!");


                }
                else
                    return new ServiceResult(false, "usertoken is missing!");

                return new ServiceResult(true);


            }
            catch (Exception ex)
            {
                return new ServiceResult(false, ex.Message);
            }
        }

        public async Task<ServiceResult<UserTokenBo>> GetByVerifyIdAsync(int id)
        {
            if (id <= 0)
                return new ServiceResult<UserTokenBo>(null, false, "id is empty!");

            try
            {
                var entity = await _unitOfWork.UserTokenRepository.GetByIdAsync(id);
                if (entity != null)
                {
                    UserTokenBo bo = _mapper.Map<UserTokenBo>(entity);
                    return new ServiceResult<UserTokenBo>(bo, true);
                }
                else
                    return new ServiceResult<UserTokenBo>(null, false, "usertoken not found!");
            }
            catch (Exception ex)
            {
                return new ServiceResult<UserTokenBo>(null, false, ex.Message);
            }
        }


        public async Task<ServiceResult<UserTokenBo>> GetByIdAsync(int id)
        {
            if (id <= 0)
                return new ServiceResult<UserTokenBo>(null, false, "ID is empty!");

            try
            {
                var entity = await _unitOfWork.UserTokenRepository.GetByIdAsync(id);
                if (entity != null)
                {
                    UserTokenBo bo = _mapper.Map<UserTokenBo>(entity);
                    return new ServiceResult<UserTokenBo>(bo, true);
                }
                else
                    return new ServiceResult<UserTokenBo>(null, false, "usertoken not found!");
            }
            catch (Exception ex)
            {
                return new ServiceResult<UserTokenBo>(null, false, ex.Message);
            }
        }
    }
}
