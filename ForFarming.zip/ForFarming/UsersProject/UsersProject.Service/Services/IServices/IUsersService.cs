﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UsersProject.Core.Model;
using UsersProject.Service.BusinessObject;

namespace UsersProject.Service.Services.IServices
{
    public interface IUsersService
    {
        Task<ServiceResult<IEnumerable<UserBo>>> GetAsync();
        Task<ServiceResult<IEnumerable<UserBo>>> FindAsync(string userName, string password);
        bool DeleteUser(UserEntity entity);
        bool UpdateUser(UserEntity entity);
    }
}
