﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UsersProject.Service.BusinessObject;

namespace UsersProject.Service.Services.IServices
{
    public interface IUserTokenService
    {
        Task<ServiceResult> ExpiryOtherDeviceTokens(int userId);
        Task<ServiceResult<UserTokenBo>> CreateAsync(UserTokenBo bo);
        Task<ServiceResult> UpdateAsync(int id, UserTokenBo bo);
        Task<ServiceResult<UserTokenBo>> GetByVerifyIdAsync(int id);
        Task<ServiceResult<UserTokenBo>> GetByIdAsync(int id);

    }
}
