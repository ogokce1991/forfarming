﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsersProject.Core.IRepositories
{
    public interface IUserTokenRepository<UserTokenEntity>
    {
        Task<IEnumerable<UserTokenEntity>> GetUserActiveToken(int userid);
        Task<UserTokenEntity> GetByIdAsync(object id);
        Task UpdateAsync(object id, UserTokenEntity entityToUpdate);
        Task InsertAsync(UserTokenEntity entity);
    }
}
