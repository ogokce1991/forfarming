﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsersProject.Core.IRepositories
{
    public interface IUserRepository<UserEntity>
    {



        Task<IEnumerable<UserEntity>> GetListAsync();
        Task InsertAsync(UserEntity entity);
        Task<IEnumerable<UserEntity>> FindAsync(string userName, string password);
        void Delete(UserEntity _object);
    }
}
