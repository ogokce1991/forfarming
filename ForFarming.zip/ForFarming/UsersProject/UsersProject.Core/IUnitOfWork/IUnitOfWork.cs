﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UsersProject.Core.IRepositories;
using UsersProject.Core.Model;

namespace UsersProject.Core.IUnitOfWork
{
    public interface IUnitOfWork
    {
        IUserRepository<UserEntity> UserRepositories { get; }
        IUserTokenRepository<UserTokenEntity> UserTokenRepository { get; }

        Task CommitAsync();
    }
}
